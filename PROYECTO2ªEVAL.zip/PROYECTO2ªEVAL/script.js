'use strict';//
//"orejón",espera a que todo el contenido html este cargado antes de ejecutarlo
document.addEventListener("DOMContentLoaded", inicio);

function inicio() {
    //contador de tiradas hechas por el usuario
    let numeroTiradas = 0;
    let posicionHeroe = { 
        x: 0,           //coordenada x inicial del heroe
        y: 0            //coordenada y inicial del heroe
    };
    let heroeMovido = true; //indica si el "heroe" se ha movido ya
    let victoriaAlcanzada = false;//indica si el usuario ha "ganado" es decir,alcanzado el cofre
    //crear el formulario para que el jugador introduzca su nombre
    const formulario = document.createElement("form");
    formulario.setAttribute("id", "formulario");//agregar sus respectivos atributos, en este caso su id,llmaado formulario
    //creamos una etiqueta para el campo nombre
    const label = document.createElement("label");
    label.setAttribute("for", "nombre");//atributos
    label.textContent = "Introduce nombre:";//Texto que aparecera en el campo
    formulario.appendChild(label);//añadir el label en el formulario
    //crear campo de entrada para que el usuario escribasu nombre
    const nombreInput = document.createElement("input");
    nombreInput.setAttribute("id", "nombre");//atributo id
    nombreInput.setAttribute("placeholder", "Tu nombre");//atributo de texto de ejemplo dentro del campo
    nombreInput.setAttribute("required", "true");//atributo para que el campo sea obligatorio
    nombreInput.setAttribute("type", "text");//atributo que especifica qeu sea de tipo texto
    formulario.appendChild(nombreInput);//añadir al formulario
    //crear elemento para que muestre mensajes al usuario
    const mensaje = document.createElement("p");
    mensaje.setAttribute("id", "mensaje");
    formulario.appendChild(mensaje);
    //creamos el boton para que el usuario introduzca el nombre
    const botonIntroducir = document.createElement("button");
    botonIntroducir.setAttribute("type", "button");//atributo para que sea de tipo boton
    botonIntroducir.setAttribute("id", "introducirNombre");//atributo con su id
    botonIntroducir.textContent = "Introducir";//texto que contiene el boton
    formulario.appendChild(botonIntroducir);//añadir al formulario
    //crear boton jugar
    const botonJugar = document.createElement("button");
    botonJugar.setAttribute("id", "jugar");
    botonJugar.setAttribute("type", "button");
    botonJugar.textContent = "Jugar";
    botonJugar.setAttribute("disabled", "true");//deshabilitar boton jugar(hasta que introduce un nombre valido)
    formulario.appendChild(botonJugar);

    document.body.appendChild(formulario);
    //crear elemento para mostrar el contador de tiradas
    const tiradasTexto = document.createElement("p");
    tiradasTexto.setAttribute("id", "contador");
    tiradasTexto.textContent = `Tiradas realizadas: ${numeroTiradas}`;
    tiradasTexto.style.display = "none"; 
    document.body.appendChild(tiradasTexto);
    //añadimos un evento al boton de "intriducir",cuando se haga click en el boton se ejecuta la funcion"vlidarNombre"
    botonIntroducir.addEventListener("click", validarNombre);
    function validarNombre(ev){
        //obtener el valor del campo de entrada,eliminando espacios
        const nombre = nombreInput.value.trim();
        //limpiar mensaje anterior
        mensaje.textContent = "";
        //usamos un if-else para comprobar si el nombre es menor a 4 caracteres
        if (nombre.length < 4) {
            //muestra mensaje si es menor a 4
            mensaje.textContent = "El nombre debe tener 4 o más LETRAS";
            //comprueba tambien sino si contiene numeros
        } else if (/\d/.test(nombre)) {
            mensaje.textContent = "El nombre no debe contener números";
        } else {
            //una vez verificado que no es numero ni menos a 4 ,significa que esta bien introducido
            mensaje.textContent = `A luchar, héroe: ${nombre}`;//sacar mensaje con el numbre deljugador
            botonJugar.removeAttribute("disabled");//borrar el deshabilitar del boton jugar(ya se puede pulsar)
            botonIntroducir.setAttribute("disabled", "true");//ahora deshabilitar boton introducir
            nombreInput.setAttribute("disabled", "true");// Deshabilita el campo de entrada para que el jugador no pueda modificar su nombre después de validarlo.

        }
    }

    // Agrega un evento al botón "Jugar" que ejecuta la función `iniciarJuego` al hacer click.
    botonJugar.addEventListener("click", iniciarJuego);
    function iniciarJuego(ev){
        // Reinicia el contador de tiradas 
        tiradasTexto.style.display = "block";
        numeroTiradas = 0;
        heroeMovido = true;//establece el estado inicial del héroe.
        localStorage.setItem("tiradas", numeroTiradas);// Guarda en `localStorage` el número de tiradas reiniciado (cero).


        generarTablero();// Llama a una función para generar el tablero de juego

        // Oculta los elementos
        botonIntroducir.style.display = "none";
        botonJugar.style.display = "none";
        label.style.display = "none";
        nombreInput.style.display = "none";
        // Actualiza el texto del contador de tiradas en pantalla.
        tiradasTexto.textContent = `Tiradas realizadas: ${numeroTiradas}`;
        // Crea un nuevo botón para tirar el dado durante el juego.
        const botonTirarDado = document.createElement("button");
        botonTirarDado.setAttribute("id", "botonTirarDado");
        botonTirarDado.textContent = "TIRAR dado";
        document.body.appendChild(botonTirarDado);
        // Agrega un evento al botón de tirar dado, que ejecuta la función `tirarDado` al hacer click.
        botonTirarDado.addEventListener("click", tirarDado);
        function tirarDado(ev){
        
            if (!heroeMovido) {// Verifica si el héroe ya se ha movido antes de permitir tirar el dado nuevamente.
                alert("Primero mueve al héroe antes de tirar el dado.");
                return;// Detiene la ejecución si el héroe no se ha movido.
            }
            // Marca que el héroe aún no se ha movido tras tirar el dado.
            heroeMovido = false;
            // Incrementa el número de tiradas y actualiza su valor en `localStorage`.
            numeroTiradas++;
            localStorage.setItem("tiradas", numeroTiradas);
            // Genera un número aleatorio entre 1 y 6 para simular la tirada del dado.
            const dado = Math.floor(Math.random() * 6) + 1;
            // Llama a funciones para mostrar el valor del dado y mover al héroe en el tablero.
            mostrarDado(dado);
            moverHeroe(dado);
            // Actualiza el texto del contador de tiradas para reflejar el nuevo número.
            tiradasTexto.textContent = `Tiradas realizadas: ${numeroTiradas}`;
        
        }
    }
    // Función para mostrar la imagen de un dado con el número proporcionado
    function mostrarDado(dado) {
        // Verificar si ya existe una imagen de dado y eliminarla si es así
        const imagenDadoAnterior = document.querySelector("#imagenDado");
        if (imagenDadoAnterior) {
            imagenDadoAnterior.remove();
        }
        // Crear un nuevo elemento de imagen 
        const imagenDado = document.createElement("img");
        
        imagenDado.setAttribute("id", "imagenDado");// Establecer el ID 
        imagenDado.setAttribute("src", `imagenes/dado${dado}.jpg`);// Establecer la fuente de la imagen con el nombre del archivo correspondiente al número del dado
        imagenDado.setAttribute("width", "100");// Establecer el tamaño de la imagen(ancho)
        imagenDado.setAttribute("height", "100");// Establecer el tamaño de la imagen(alto)
        document.body.appendChild(imagenDado);// Añadir la imagen al cuerpo del documento
    }
    // Función para generar el tablero de juego
    function generarTablero() {
        mensaje.style.display = "none";
        const tablero = document.createElement("div");// Crear el contenedor principal del tablero
        tablero.setAttribute("id", "tablero");//Establecer id
        tablero.style.display = "grid";// Usamos grid para organizar las celdas
        tablero.style.gridTemplateColumns = "repeat(10, 50px)";// Crear 10 columnas de 50px
        tablero.style.gap = "2px"; // Espacio entre las celdas
        document.body.appendChild(tablero);
        // Crear las celdas del tablero
        for (let i = 0; i < 10; i++) {
            for (let j = 0; j < 10; j++) {
                const celda = document.createElement("div");
                celda.setAttribute("id","celda");
                celda.style.width = "50px";
                celda.style.height = "50px";
                // Colocar la imagen del héroe en la celda (0, 0)
                if (i === 0 && j === 0) {
                    const heroeImagen = document.createElement("img");
                    heroeImagen.setAttribute("id", "heroe");
                    heroeImagen.setAttribute("src", "imagenes/heroe.jpg");// Ruta de la imagen
                    heroeImagen.style.width = "100%";// Ajustar tamaño al 100% de la celda
                    heroeImagen.style.height = "100%";
                    heroeImagen.style.objectFit = "cover";// Cubrir toda la celda
                    celda.appendChild(heroeImagen);
                } else if (i === 9 && j === 9) {// Colocar la imagen del cofre en la celda (9, 9)-->ultima casilla
                    const cofreImagen = document.createElement("img");
                    cofreImagen.setAttribute("src", "imagenes/cofre.png");
                    cofreImagen.style.width = "100%";
                    cofreImagen.style.height = "100%";
                    cofreImagen.style.objectFit = "cover";
                    celda.appendChild(cofreImagen);
                    
                } else {// Colocar la imagen de suelo en otras celdas
                    const imagenSuelo = document.createElement("img");
                    imagenSuelo.setAttribute("src", "imagenes/suelo.jpg");
                    imagenSuelo.style.width = "100%";
                    imagenSuelo.style.height = "100%";
                    
                    imagenSuelo.style.objectFit = "cover";
                    celda.appendChild(imagenSuelo);
                }
                // Agregar cada celda al tablero
                tablero.appendChild(celda);
            }
        }
    }
    function moverHeroe(dado) {
        const celdas = document.querySelectorAll("#tablero div");

        // Limpiar las capas rojas previas
        celdas.forEach(celda => {
            const capaRoja = celda.querySelector(".rojo");
            if (capaRoja) capaRoja.remove();
        });

        // Calcular nuevas posiciones posibles
        const nuevasPosiciones = [];
        const { x: fila, y: columna } = posicionHeroe;

        for (let i = 1; i <= dado; i++) {
            if (columna + i < 10) nuevasPosiciones.push({ x: fila, y: columna + i });
            if (fila + i < 10) nuevasPosiciones.push({ x: fila + i, y: columna });
            if (columna - i >= 0) nuevasPosiciones.push({ x: fila, y: columna - i });
            if (fila - i >= 0) nuevasPosiciones.push({ x: fila - i, y: columna });
        }

        // Añadir las capas rojas a las nuevas posiciones posibles
        nuevasPosiciones.forEach(pos => {
            const indice = pos.x * 10 + pos.y;
            const celda = celdas[indice];

            if (celda) {
                const capaRoja = document.createElement("div");
                capaRoja.classList.add("rojo");
                capaRoja.style.position = "absolute";
                capaRoja.style.top = "0";
                capaRoja.style.left = "0";
                capaRoja.style.width = "100%";
                capaRoja.style.height = "100%";
                capaRoja.style.backgroundColor = "red";
                capaRoja.style.zIndex = "10";

                // Evento para mover al héroe a la celda seleccionada
                capaRoja.addEventListener("click", () => {
                    // Eliminar la imagen del héroe de la celda actual
                    const celdaAnterior = celdas[posicionHeroe.x * 10 + posicionHeroe.y];
                    celdaAnterior.innerHTML = ""; // Eliminar todo el contenido de la celda anterior

                    // Reemplazar el contenido de la nueva celda con la imagen del héroe
                    celda.innerHTML = ""; // Vaciar el contenido de la nueva celda
                    const heroeImagen = document.createElement("img");
                    heroeImagen.setAttribute("id", "heroe");
                    heroeImagen.setAttribute("src", "imagenes/heroe.jpg");
                    heroeImagen.style.width = "100%";
                    heroeImagen.style.height = "100%";
                    heroeImagen.style.objectFit = "cover";

                    celda.appendChild(heroeImagen);

                    // Actualizar la posición del héroe
                    posicionHeroe = { x: pos.x, y: pos.y };
                    heroeMovido = true;

                    // Eliminar todas las capas rojas
                    celdas.forEach(celda => {
                        const capaRoja = celda.querySelector(".rojo");
                        if (capaRoja) capaRoja.remove();
                    });

                    // Verificar si el héroe ha llegado al cofre (posición [9, 9])
                    if (posicionHeroe.x === 9 && posicionHeroe.y === 9) {
                        setTimeout(() => mostrarVictoria(), 300);
                    }
                    
                });

                celda.appendChild(capaRoja);
            }
        });
    }

    
    function mostrarVictoria() {
        
        const tiradasRealizadas = localStorage.getItem("tiradas");// Obtener el número de tiradas realizadas
        alert(`¡Victoria! Has alcanzado el cofre en ${tiradasRealizadas} tiradas.`);// Mostrar mensaje de victoria
    
        const recordTiradas = localStorage.getItem("record");// Verificar si es un nuevo récord
    
        if (recordTiradas && parseInt(tiradasRealizadas) >= parseInt(recordTiradas)) {
            alert(`Récord no superado. El récord actual es ${recordTiradas} tiradas.`);// No se supera el récord
        } else {
           localStorage.setItem("record", tiradasRealizadas); // Nuevo récord
            alert(`¡Nuevo récord! Ahora el récord es ${tiradasRealizadas} tiradas.`);
        }
    
        // Desactivar el botón de tirar el dado
        const botonTirarDado = document.querySelector("#botonTirarDado");
        if (botonTirarDado) {
            botonTirarDado.setAttribute("disabled", "true");
            botonTirarDado.textContent = "Juego Terminado";
        }
        const imagenDado = document.querySelector("#imagenDado");
            if (imagenDado) {
                imagenDado.remove();
        }
        victoriaAlcanzada = true;// Bloquear más movimientos
    }
    
    
    
    

}
